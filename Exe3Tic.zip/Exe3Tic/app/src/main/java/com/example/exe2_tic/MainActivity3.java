package com.example.exe2_tic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {
    private TextView Resultado;
    private Intent i ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Toast t = new Toast(getApplicationContext());

        Resultado = findViewById(R.id.Resultado);
        Resultado.setText("");
        i = getIntent();

        String nome1 = i.getExtras().getString("nome1");
        String nome2 = i.getExtras().getString("nome2");

        if(nome1.isEmpty() && nome2.isEmpty() )
            t.makeText(this , "Nome não Inserido", Toast.LENGTH_LONG).show();
        else
            t.makeText(this , "Olá " + nome1 + " " + nome2 , Toast.LENGTH_LONG).show();




    }
}