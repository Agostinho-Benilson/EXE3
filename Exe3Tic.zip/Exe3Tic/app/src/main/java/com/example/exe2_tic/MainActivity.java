package com.example.exe2_tic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText nome1;
    private Button btnok1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nome1 = findViewById(R.id.nome1);
        btnok1 = findViewById(R.id.btnok1);
    }

    public void ok1 (View view){
        Intent intent = new Intent(getApplicationContext() , MainActivity2.class );
        intent.putExtra("nome1" ,  nome1.getText().toString());
        startActivity(intent);

    }


}