package com.example.exe2_tic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity2 extends AppCompatActivity {
    private EditText nome2;
    private Button btnok2;
    private Intent intent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        nome2 = findViewById(R.id.nome2);
        btnok2 = findViewById(R.id.btnok2);
        intent = getIntent();
    }

    public void ok2 (View view){
        String nome1 = intent.getExtras().getString("nome1");
         intent = new Intent(getApplicationContext() , MainActivity3.class );

        intent.putExtra("nome1" , nome1);
        intent.putExtra("nome2" ,  nome2.getText().toString());


        startActivity(intent);

    }
}